# Modifying TBB for use within USDJ

This folder contains the development dependencies for TBB 2019.

The original libraries were obtained from:

https://github.com/oneapi-src/oneTBB/releases/download/2019_U6/tbb2019_20190410oss_win.zip

Notice that we only include `tbb.*` and `tbbmalloc.*` in this distribution (see
below in case you need to include other libs).

The original libraries are named without any version or date suffix (`tbb.lib`,
`tbb.dll`, `tbbmalloc.lib`, ...). To avoid conflicts with other tbb libraries
that might be used in host applications (e.g. Maya), we renamed the libraries
to:

```
tbb-2019.dll
tbb-2019.lib
tbbmalloc-2019.dll
tbbmalloc-2019.lib
```

The renaming was performed using the `lib` command line utility (available with
Visual Studio) and preserving the original symbol names:

```
# Copy and rename the .def files.
copy tbb.def tbb-2019.def
copy tbbmalloc.def tbbmalloc-2019.def

# Create the renamed libraries and copy/rename the original dlls.
lib /MACHINE:X64 /DEF:tbb-2019.def
copy tbb.dll tbb-2019.dll

lib /MACHINE:X64 /DEF:tbbmalloc-2019.def
copy tbbmalloc.dll tbbmalloc-2019.dll
```

The following URL provides a script with similar functionalities:

https://github.com/cmberryau/rename_dll/blob/master/rename_dll.py
